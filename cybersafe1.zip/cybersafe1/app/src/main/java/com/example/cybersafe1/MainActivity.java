package com.example.cybersafe1;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton law_btn,sec_btn,phem_btn,phca_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this, "Hello",Toast.LENGTH_SHORT).show();

        ImageButton law_btn=(ImageButton)findViewById(R.id.law_btn);
        ImageButton sec_btn=(ImageButton)findViewById(R.id.sec_btn);
        ImageButton phem_btn=(ImageButton)findViewById(R.id.phem_btn);
        ImageButton phca_btn=(ImageButton)findViewById(R.id.phca_btn);

        law_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,cybercell.class);
                startActivity(intent);
            }
        });
        sec_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, cybercell.class);
                startActivity(intent);
            }
        });
        phem_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,phem.class);
                startActivity(intent);
            }
        });
        phca_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,phca.class);
                startActivity(intent);
            }
        });


    }
}
