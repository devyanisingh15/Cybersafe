package com.example.cybersafe1;

public class phemt {
    private String email;
    private String category;
    private String comments;

    public phemt() {

    }

    public phemt(String email, String category,String comments){
        this.email=email;
        this.category=category;
        this.comments = comments;
    }

    public String getEmail() {
        return email;
    }

    public String getCategory() {
        return category;
    }

    public String getComments() {
        return comments;
    }


}
