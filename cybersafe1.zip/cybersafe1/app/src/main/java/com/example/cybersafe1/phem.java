package com.example.cybersafe1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class phem extends AppCompatActivity {
    EditText email,category,comments;
    Button savebtn;
    private DatabaseReference mDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phem);
        mDatabase = FirebaseDatabase.getInstance().getReference("phemt");

        email =(EditText) findViewById(R.id.input_email);
        category =(EditText) findViewById(R.id.input_category);
        comments = (EditText)findViewById(R.id.input_comments);
        savebtn=(Button)findViewById(R.id.button);

        savebtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClients();

            }
        } );


    }
    public void addClients() {
        String clientemail = email.getText().toString();
        String clientcategory = category.getText().toString();
        String clientcomments = comments.getText().toString();

        if (!TextUtils.isEmpty( clientemail)&& !TextUtils.isEmpty( clientcategory )) {

            String id = mDatabase.push().getKey();
            phemt phemt= new phemt( clientemail,clientcategory,clientcomments );

            mDatabase.child( id ).setValue( phemt );
            email.setText( "" );
            category.setText( "" );
            comments.setText( "" );


        } else {
            Toast.makeText( phem.this, "please fill", Toast.LENGTH_SHORT ).show();
        }
    }
}
