package com.example.cybersafe1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class phca extends AppCompatActivity {
    EditText number,category,comments;
    Button savebtn;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phca);

        mDatabase = FirebaseDatabase.getInstance().getReference("phcat");


        number =(EditText) findViewById(R.id.input_number);
        category =(EditText) findViewById(R.id.input_category);
        comments = (EditText)findViewById(R.id.input_comments);
        savebtn=(Button)findViewById(R.id.btn);

        savebtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               addClients();
            }
        } );
    }
    public void addClients() {
        String clientnumber = number.getText().toString();
        String clientcategory = category.getText().toString();
        String clientcomments = comments.getText().toString();

        if (!TextUtils.isEmpty( clientnumber)&& !TextUtils.isEmpty( clientcategory )) {

            String id = mDatabase.push().getKey();
            phcat phcat= new phcat( clientnumber,clientcategory,clientcomments );

            mDatabase.child( id ).setValue( phcat );
            number.setText( "" );
            category.setText( "" );
            comments.setText( "" );


        } else {
            Toast.makeText( phca.this, "please fill", Toast.LENGTH_SHORT ).show();
        }
    }
}
