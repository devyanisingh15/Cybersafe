package com.example.cybersafe1;

public class phcat {
    private String number;
    private String category;
    private String comments;


    public phcat() {

    }

    public phcat(String number, String category,String comments){
        this.number=number;
        this.category=category;
        this.comments = comments;
    }

    public String getNumber() {
        return number;
    }

    public String getCategory() {
        return category;
    }

    public String getComments() {
        return comments;
    }
}
